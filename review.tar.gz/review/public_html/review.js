(function () {
    'use strict';
     
    var app = angular.module('application', []);
    app.controller('reviewController', function ($scope) {
         
    });
})();